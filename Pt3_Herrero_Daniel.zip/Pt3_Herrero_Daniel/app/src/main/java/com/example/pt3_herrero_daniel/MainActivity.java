package com.example.pt3_herrero_daniel;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int countCreate = 0;
    private int countStart = 0;
    private int countRestart = 0;
    private int countResume = 0;
    private int countPause = 0;
    private int countStop = 0;
    private int countDestroy = 0;

    private TextView tvCreate, tvStart, tvRestart, tvResume, tvPause, tvStop, tvDestroy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvCreate = findViewById(R.id.tvCreate);
        tvStart = findViewById(R.id.tvStart);
        tvRestart = findViewById(R.id.tvRestart);
        tvResume = findViewById(R.id.tvResume);
        tvPause = findViewById(R.id.tvPause);
        tvStop = findViewById(R.id.tvStop);
        tvDestroy = findViewById(R.id.tvDestroy);

        if (savedInstanceState != null) {
            countCreate = savedInstanceState.getInt("countCreate");
            countStart = savedInstanceState.getInt("countStart");
            countRestart = savedInstanceState.getInt("countRestart");
            countResume = savedInstanceState.getInt("countResume");
            countPause = savedInstanceState.getInt("countPause");
            countStop = savedInstanceState.getInt("countStop");
            countDestroy = savedInstanceState.getInt("countDestroy");
        }

        countCreate++;
        updateUI();
    }

    @Override
    protected void onStart() {
        super.onStart();
        countStart++;
        updateUI();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        countRestart++;
        updateUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        countResume++;
        updateUI();
    }

    @Override
    protected void onPause() {
        super.onPause();
        countPause++;
        updateUI();
    }

    @Override
    protected void onStop() {
        super.onStop();
        countStop++;
        updateUI();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        countDestroy++;
        // Nota: El UI no se actualizará aquí porque la actividad se está destruyendo
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("countCreate", countCreate);
        outState.putInt("countStart", countStart);
        outState.putInt("countRestart", countRestart);
        outState.putInt("countResume", countResume);
        outState.putInt("countPause", countPause);
        outState.putInt("countStop", countStop);
        outState.putInt("countDestroy", countDestroy);
    }

    private void updateUI() {
        try {
            tvCreate.setText(getString(R.string.on_create_count, countCreate));
            tvStart.setText(getString(R.string.on_start_count, countStart));
            tvRestart.setText(getString(R.string.on_restart_count, countRestart));
            tvResume.setText(getString(R.string.on_resume_count, countResume));
            tvPause.setText(getString(R.string.on_pause_count, countPause));
            tvStop.setText(getString(R.string.on_stop_count, countStop));
            tvDestroy.setText(getString(R.string.on_destroy_count, countDestroy));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
