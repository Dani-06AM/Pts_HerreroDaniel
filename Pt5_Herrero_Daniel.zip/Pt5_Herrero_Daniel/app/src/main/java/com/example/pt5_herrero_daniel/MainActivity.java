package com.example.pt5_herrero_daniel;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private TextView tvDisplaySettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvDisplaySettings = findViewById(R.id.tvDisplaySettings);
        Button btnSettings = findViewById(R.id.btnSettings);
        Button btnRefresh = findViewById(R.id.btnRefresh);

        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadPreferences();
            }
        });

        loadPreferences();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPreferences();
    }

    private void loadPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        
        String name = sharedPreferences.getString("user_name", "No definit");
        Set<String> races = sharedPreferences.getStringSet("star_wars_races_pref", new HashSet<String>());
        boolean notifications = sharedPreferences.getBoolean("notifications_pref", true);
        String movie = sharedPreferences.getString("favorite_movie_pref", "No definida");

        StringBuilder sb = new StringBuilder();
        sb.append("Nom: ").append(name).append("\n\n");
        sb.append("Races preferides:\n");
        if (races.isEmpty()) {
            sb.append("- Cap\n");
        } else {
            for (String race : races) {
                sb.append("- ").append(race).append("\n");
            }
        }
        sb.append("\nNotificacions: ").append(notifications ? "Actives" : "Inactives").append("\n");
        sb.append("Pel·lícula preferida: ").append(movie);

        tvDisplaySettings.setText(sb.toString());
    }
}
