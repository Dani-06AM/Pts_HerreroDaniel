package com.example.pt4_herrero_daniel;

import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AlarmActivity extends AppCompatActivity {

    private EditText etHour, etMinute, etMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);

        etHour = findViewById(R.id.etHour);
        etMinute = findViewById(R.id.etMinute);
        etMessage = findViewById(R.id.etMessage);
        Button btnCreateAlarm = findViewById(R.id.btnSetAlarm);

        btnCreateAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAlarm();
            }
        });
    }

    private void createAlarm() {
        String hourStr = etHour.getText().toString();
        String minuteStr = etMinute.getText().toString();
        String message = etMessage.getText().toString();

        if (hourStr.isEmpty() || minuteStr.isEmpty()) {
            Toast.makeText(this, "Por favor, introduce hora y minuto", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int hour = Integer.parseInt(hourStr);
            int minute = Integer.parseInt(minuteStr);

            if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
                Toast.makeText(this, "Hora o minuto inválido", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, message)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false);

            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            } else {
                Toast.makeText(this, "No hay ninguna aplicación de reloj instalada", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Introduce números válidos", Toast.LENGTH_SHORT).show();
        }
    }
}
