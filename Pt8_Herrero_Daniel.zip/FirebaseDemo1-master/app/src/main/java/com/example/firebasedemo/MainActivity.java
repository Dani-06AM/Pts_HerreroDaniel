package com.example.firebasedemo;

import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.firebasedemo.databinding.ActivityMainBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private DatabaseReference database;
    private QuestAdapter adapter;
    private List<Quest> questList = new ArrayList<>();
    private final String dbUrl = "https://fir-demo-5c533-default-rtdb.europe-west1.firebasedatabase.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Inicializar Firebase Realtime Database
        database = FirebaseDatabase.getInstance(dbUrl).getReference("quests");

        setupRecyclerView();
        setupListeners();
        observeQuests();
    }

    private void setupRecyclerView() {
        adapter = new QuestAdapter(questList);
        binding.rvQuests.setLayoutManager(new LinearLayoutManager(this));
        binding.rvQuests.setAdapter(adapter);
    }

    private void setupListeners() {
        binding.btnAnadir.setOnClickListener(v -> {
            String nombre = binding.etNombre.getText().toString().trim();
            String descripcion = binding.etDescripcion.getText().toString().trim();

            if (!nombre.isEmpty() && !descripcion.isEmpty()) {
                saveQuest(nombre, descripcion);
            } else {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveQuest(String nombre, String descripcion) {
        String id = database.push().getKey();
        if (id == null) return;

        Quest nuevaQuest = new Quest(id, nombre, descripcion, new Random().nextInt(5) + 1);

        database.child(id).setValue(nuevaQuest)
                .addOnSuccessListener(aVoid -> {
                    binding.etNombre.setText("");
                    binding.etDescripcion.setText("");
                    Toast.makeText(MainActivity.this, "Quest añadida con éxito", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(MainActivity.this, "Error al guardar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void observeQuests() {
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                questList.clear();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Quest quest = postSnapshot.getValue(Quest.class);
                    if (quest != null) {
                        questList.add(quest);
                    }
                }
                adapter.updateList(questList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Error al leer datos: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
