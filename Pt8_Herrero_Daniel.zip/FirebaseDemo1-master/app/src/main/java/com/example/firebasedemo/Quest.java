package com.example.firebasedemo;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Quest {
    public String id;
    public String nombre;
    public String descripcion;
    public int prioridad;

    // Constructor vacío requerido por Firebase
    public Quest() {
    }

    public Quest(String id, String nombre, String descripcion, int prioridad) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.prioridad = prioridad;
    }
}
