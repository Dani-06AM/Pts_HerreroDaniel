package com.example.firebasedemo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class QuestAdapter extends RecyclerView.Adapter<QuestAdapter.QuestViewHolder> {
    private List<Quest> questList;

    public QuestAdapter(List<Quest> questList) {
        this.questList = questList;
    }

    @NonNull
    @Override
    public QuestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_quest, parent, false);
        return new QuestViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull QuestViewHolder holder, int position) {
        Quest quest = questList.get(position);
        holder.tvNombre.setText(quest.nombre);
        holder.tvDescripcion.setText(quest.descripcion);
        holder.tvPrioridad.setText("Prioridad: " + quest.prioridad);
    }

    @Override
    public int getItemCount() {
        return questList.size();
    }

    public void updateList(List<Quest> newList) {
        this.questList = newList;
        notifyDataSetChanged();
    }

    static class QuestViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvDescripcion, tvPrioridad;

        public QuestViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvQuestNombre);
            tvDescripcion = itemView.findViewById(R.id.tvQuestDescripcion);
            tvPrioridad = itemView.findViewById(R.id.tvQuestPrioridad);
        }
    }
}
