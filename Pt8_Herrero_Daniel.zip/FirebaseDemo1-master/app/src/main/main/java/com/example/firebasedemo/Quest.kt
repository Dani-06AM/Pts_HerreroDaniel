package com.example.firebasedemo

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class Quest(
    val id: String? = null,
    val nombre: String? = "",
    val descripcion: String? = "",
    val prioridad: Int? = 0
)
